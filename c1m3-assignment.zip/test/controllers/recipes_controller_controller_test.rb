require 'test_helper'

class RecipesControllerControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
